#!/bin/bash

set -x 

#export MV2_SHOW_CPU_BINDING=1
#export MV2_ENABLE_AFFINITY=1
#export MV2_CPU_BINDING_POLICY=hybrid
#export MV2_HYBRID_BINDING_POLICY=cgread 
export OMP_NUM_THREADS=1

export LD_LIBRARY_PATH=/home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/lib
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 2 -f 2-nole-7-9 ./osu_mbw_mr

time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 4 -f 4-nole-7-9 ./osu_mbw_mr

time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 8 -f 8-nole-7-9 ./osu_mbw_mr

time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 16 -f 16-nole-7-9 ./osu_mbw_mr

time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
time /home/naser/ics-2020/unencrypted-base/mpich-3.2.1/install/bin/mpiexec  -n 32 -f 32-nole-7-9 ./osu_mbw_mr
