#!/bin/bash
set -e
set -x

RED='\033[0;31m'
NC='\033[0m' # No Color
red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`
#export LD_LIBRARY_PATH=/home/mpiuser/msg-chopping--boring-ssl-mpich-3.2.1/msg_chopping_install_boringssl/lib:/home/mpiuser/libsodium-stable/libsodium_install/lib:/home/mpiuser/boringssl/build/crypto
#MPICC=/home/mpiuser/msg-chopping--boring-ssl-mpich-3.2.1/msg_chopping_install_boringssl/bin/MPICH_3.2.1_boringssl_mpicc
#MPIEXEC=/home/mpiuser/msg-chopping--boring-ssl-mpich-3.2.1/msg_chopping_install_boringssl/bin/MPICH_3.2.1_boringssl_mpiexec
export LD_LIBRARY_PATH=/home/mpiuser/sc-2019/mpich-3.2.1/install/lib:/home/mpiuser/boringssl/build/crypto
MPICC=/home/mpiuser/sc-2019/mpich-3.2.1/install/bin/mpicc
MPIEXEC=/home/mpiuser/sc-2019/mpich-3.2.1/install/bin/mpiexec

echo "${green}**********************************************************${reset}"
echo -e "${RED}Testing alltoallv....${NC}"

cd test/alltoallv-test-files
rm i-neg f-neg 
if [ -e alltoallv-test.md ] 
then
    rm alltoallv-test.md
fi

$MPICC -o i-neg alltoallv-int-negative.c
$MPICC -o f-neg  alltoallv-float-negative.c  
ls -lah

echo "${green} alltoallv-int-negative:${reset}"
echo "------------------------"
$MPIEXEC -n 4 ./i-neg > alltoallv-test.md
echo "${green} alltoallv-float-negative:${reset}"
echo "--------------------------"
$MPIEXEC -n 4 ./f-neg >> alltoallv-test.md

echo "${green}Testing alltoallv done........${reset}"
echo "${green}******************************************${reset}"
echo -e "${RED}Testing alltoall....${NC}"

cd ../all-to-all-test-files
rm i i-neg f-neg 
if [ -e alltoall-test.md ] 
then
    rm alltoall-test.md
fi
$MPICC -o i     all-to-all-int.c
$MPICC -o i-neg all-to-all-int-negative.c
$MPICC -o f-neg all-to-all-float-negative.c   
ls -lah
echo "${green} alltoall-int:${reset}"
echo "---------------"
$MPIEXEC -n 4 ./i > alltoall-test.md
echo "${green} alltoall-int-negative:${reset}"
echo "------------------------"
$MPIEXEC -n 4 ./i-neg  >> alltoall-test.md
echo " ${green}alltoall-float-negative:${reset}"
echo "-------------------------"
$MPIEXEC -n 4 ./f-neg >> alltoall-test.md

echo "${green}Testing alltoall done........"
echo "******************************************${reset}"
echo -e "${RED}Testing allgather....${NC}"

cd ../all-gather-test-files
rm i i-neg f-neg 
if [ -e allgather-test.md ] 
then
    rm allgather-test.md
fi
$MPICC -o i     all-gather-int.c 
$MPICC -o i-neg all-gather-int-negative.c
$MPICC -o f-neg all-gather-float-negative.c   
ls -lah

echo "${green} allgather-int:${reset}"
echo "---------------"
$MPIEXEC -n 4 ./i > allgather-test.md
echo "${green} allgather-int-negative:${reset}"
echo "------------------------"
$MPIEXEC -n 4 ./i-neg >> allgather-test.md 
echo "${green} allgather-float-negative:${reset}"
echo "--------------------------"
$MPIEXEC -n 4 ./f-neg >> allgather-test.md

echo "${green}Testing allgather done........"
echo "******************************************${reset}"
echo -e "${RED}Testing bcast....${NC}"

cd ../bcast
rm  i-neg f-neg 
if [ -e bcast-test.md ] 
then
    rm bcast-test.md
fi
$MPICC -o i-neg  bcast-int-negative.c
$MPICC -o f-neg bcast-float-negative.c 
ls -lah

echo "${green}bcast-int-negative:${reset}"
echo "-------------------"
$MPIEXEC -n 4 ./i-neg > bcast-test.md
echo "${green}bcast-float-negative:${reset}"
echo "-------------------"
$MPIEXEC -n 4 ./f-neg >> bcast-test.md

echo "${green}Testing bcast done........"
echo "******************************************${reset}"

#echo -e "${RED}Testing chopping send-irecv-wait...."
#cd /home/mpiuser/msg-chopping--boring-ssl-mpich-3.2.1/examples/choping/irecv/

#rm  i-recv

#$MPICC -o i-recv  irecv-wait.c
#ls -lah

#echo "chopping send-irecv-wait:"
#echo "-------------------"
#$MPIEXEC -n 2 ./i-recv


#echo "Testing chopping send-irecv-wait done........"

