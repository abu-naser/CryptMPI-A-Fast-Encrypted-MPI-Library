#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define FLOAT_PRECISION 5
#define FIELD_WIDTH 20
#define sz 4*1024*1024
#define MG 1048576.00
#define low 1*1024//4*1024//512*1024 
#define high 4*1024*1024//(4*1024*1024)*1.1
#define times 1000
#define max_pack 2*1024
#define SIZE_NUM 10 //10 //11
#define key_size 16
#define normal 1
#define GCM 0
#define OCB 0
#define CTR 0
#define PreCtr 0


static int lengths[SIZE_NUM+10] = { 1 , 16 , 256 , 1024, 4*1024 , 16*1024 , 64*1024 , 256*1024 , 1024*1024 , 2*1024*1024 , 4* 1024*1024};
static int lengths2[SIZE_NUM+10] = { 16 ,16 ,16 ,16 ,16 ,16 ,16 ,16 ,16 ,16 ,16 };
static int lengths3[SIZE_NUM+10] = { 1, 4, 8, 16 , 32 , 64, 128 , 256 };
static int lengths4[SIZE_NUM+10] =   { 1 , 16 , 32,    48,    128,     256,       512,      1024,      2*1024,    3*1024,    4*1024};



int main(int argc, char** argv) {

	//libdumpi_disable_profiling();

  MPI_Init(NULL, NULL);
  MPI_Request request;
  MPI_Status status;
  int world_rank,world_size,j,datasz,iteration,datasz1;
  char * sendbuf, *recvbuf;
  double t_start, t_end, t;
  //struct timeval  tv1, tv2;

  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);

  sendbuf = (char *)malloc(sz * sizeof(char));
  recvbuf = (char *)malloc(sz * sizeof(char));

  memset(sendbuf,'a',4194304);
  memset(recvbuf,'b',4194304);


  // We are assuming at least 2 processes for this 
  if (world_size != 2) {
    fprintf(stderr, "World size must be two for %s\n", argv[0]);
    MPI_Abort(MPI_COMM_WORLD, 1);
  }
#if 0
   if (key_size==16 && GCM==1) {
		//if(world_rank == 0) printf("\n\t\t****** Secure Run with OpenSSL  128 ********\n");
		init_openssl_128();
	}
	else if(key_size==32 && GCM==1) {
		//if(world_rank == 0)  printf("\n\t\t****** Secure Run with OpenSSL  256 ********\n");
		init_openssl_256();
	}
	else if (key_size==16 && OCB==1) {
		//if(world_rank == 0) printf("\n\t\t****** Secure Run with OpenSSL OCB 128 ********\n");
		init_ocb_128();
	}
	else if(key_size==32 && OCB==1) {
		//if(world_rank == 0)  printf("\n\t\t****** Secure Run with OpenSSL OCB 256 ********\n");
		init_ocb_256();
	}
	else if (key_size==16 && CTR==1) {
//if(world_rank == 0) printf("\n\t\t****** Secure Run with OpenSSL CTR 128 ********\n");
		init_ctr_128();
	}
	else if(key_size==32 && CTR==1) {
		//if(world_rank == 0)  printf("\n\t\t****** Secure Run with OpenSSL CTR 256 ********\n");
		init_ctr_256();
	}
	else if (key_size==16 && PreCtr==1) {
		if(world_rank == 0) printf("\n\t\t****** Secure Run with OpenSSL PreCtr 128 ********\n");
		init_prectr_128();
	}
	else if(key_size==32 && PreCtr==1) {
		if(world_rank == 0)  printf("\n\t\t****** Secure Run with OpenSSL PreCtr 256 ********\n");
		init_prectr_256();
	}
	#endif
	//libdumpi_enable_profiling();

   
  //if (world_rank == 0) {printf("\n\t\t****** Secure Run with OpenSSL  ********\n");} 
	if(world_rank == 0) printf("\n# Size           Bandwidth (MB/s)\n");
	
	iteration = times;
	int indx;
	
	if (normal){
		 printf("Normal mode\n");
	   for(indx=9; indx<SIZE_NUM; indx++){    
			datasz=lengths[indx];
			if(datasz > 1024*1024)       iteration = 1000;

		   for(j=1;j<=iteration+20;j++){
					if(j == 20){
					  t_start = MPI_Wtime();
					}
					if (world_rank == 0) {
						  //printf("before send\n");
						  MPI_Send(sendbuf, datasz, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
							//printf("before recv\n");
						  MPI_Recv(recvbuf, datasz, MPI_CHAR, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
							//printf("after recv\n");

					}
					else if(world_rank == 1){
						  MPI_Recv(recvbuf, datasz, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
						  MPI_Send(sendbuf, datasz, MPI_CHAR, 0, 1, MPI_COMM_WORLD);
					}
				}
			t_end = MPI_Wtime();
			if(world_rank == 0) {
				t = t_end - t_start;
				 double tmp = (datasz * 2) / MG * iteration;

			   fprintf(stdout, "%-*d%*.*f\n", 10, datasz, FIELD_WIDTH,
							FLOAT_PRECISION, tmp / t);

				fflush(stdout);
				}
	  }
	//libdumpi_disable_profiling();

	}
	#if 0
	else if (PreCtr==1){
		for(indx=0; indx<SIZE_NUM; indx++){    
		datasz=lengths4[indx];
		if(datasz > 1024*1024)       iteration = 1000;
		for(j=1;j<=iteration+20;j++){
				if(j == 20){
				  t_start = MPI_Wtime();
				}
				if (world_rank == 0) {
					  MPI_PreCtr_Isend(sendbuf, datasz, MPI_CHAR, 1, 0, MPI_COMM_WORLD, &request);
					  MPI_Psend_Wait(&request, &status,1);
					  //MPI_PreCtr_Recv(recvbuf, datasz, MPI_CHAR, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE,max_pack);
					  MPI_PreCtr_Recv(recvbuf, datasz, MPI_CHAR, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				}
				else if(world_rank == 1){
					  //MPI_PreCtr_Recv(recvbuf, datasz, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE,max_pack);
					  MPI_PreCtr_Recv(recvbuf, datasz, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
					  //MPI_PreCtr_Send(sendbuf, datasz, MPI_CHAR, 0, 1, MPI_COMM_WORLD,max_pack);
					  MPI_PreCtr_Isend(sendbuf, datasz, MPI_CHAR, 0, 1, MPI_COMM_WORLD, &request);
					  MPI_Psend_Wait(&request, &status,0);
					  
			}
		}
		t_end = MPI_Wtime();
		if(world_rank == 0) {
			t = t_end - t_start;
			//printf("datasz =%d t = %lf\n", datasz,t);
			// tmp = Total data sent in MegaByte
			//double tmp = datasz / 1e6 * 1000;
			 double tmp = (datasz * 2) / MG * iteration;
			//printf("datasz =%d tmp = %lf\n", datasz,tmp);
			//printf("** %d total data sent in MB = %f time took %f\n", datasz,tmp,t);fflush(stdout);
			fprintf(stdout, "%-*d%*.*f\n", 10, datasz, FIELD_WIDTH,	FLOAT_PRECISION, tmp / t);

			fflush(stdout);
        }
	}
	}
	else if (CTR==1){
		for(indx=0; indx<SIZE_NUM; indx++){    
		datasz=lengths4[indx];
		if(datasz > 1024*1024)       iteration = 1000;
		for(j=1;j<=iteration+20;j++){
				if(j == 20){
				  t_start = MPI_Wtime();
				}
				if (world_rank == 0) {
					  MPI_CTR_Send(sendbuf, datasz, MPI_CHAR, 1, 0, MPI_COMM_WORLD,max_pack);
					  MPI_CTR_Recv(recvbuf, datasz, MPI_CHAR, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE,max_pack);
				}
				else if(world_rank == 1){
					  MPI_CTR_Recv(recvbuf, datasz, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE,max_pack);
					  MPI_CTR_Send(sendbuf, datasz, MPI_CHAR, 0, 1, MPI_COMM_WORLD,max_pack);
			}
		}
		t_end = MPI_Wtime();
		if(world_rank == 0) {
			t = t_end - t_start;
			//printf("datasz =%d t = %lf\n", datasz,t);
			// tmp = Total data sent in MegaByte
			//double tmp = datasz / 1e6 * 1000;
			 double tmp = (datasz * 2) / MG * iteration;
			//printf("datasz =%d tmp = %lf\n", datasz,tmp);
			//printf("** %d total data sent in MB = %f time took %f\n", datasz,tmp,t);fflush(stdout);
			fprintf(stdout, "%-*d%*.*f\n", 10, datasz, FIELD_WIDTH,	FLOAT_PRECISION, tmp / t);

			fflush(stdout);
        }
		}
	}
	else {
	for(indx=0; indx<SIZE_NUM; indx++){    
		datasz=lengths[indx];
		if(datasz > 1024*1024)       iteration = 1000;
		for(j=1;j<=iteration+20;j++){
				if(j == 20){
				  t_start = MPI_Wtime();				 
				}				
				if (world_rank == 0) {
					  MPI_SEC_Send(sendbuf, datasz, MPI_CHAR, 1, 0, MPI_COMM_WORLD,max_pack);
					  MPI_SEC_Recv(recvbuf, datasz, MPI_CHAR, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE,max_pack);					
				}
				else if(world_rank == 1){					
					  MPI_SEC_Recv(recvbuf, datasz, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE,max_pack);
					  MPI_SEC_Send(sendbuf, datasz, MPI_CHAR, 0, 1, MPI_COMM_WORLD,max_pack);					
			}
		}
		t_end = MPI_Wtime();
		if(world_rank == 0) {
			t = t_end - t_start;
			//printf("datasz =%d t = %lf\n", datasz,t);
			// tmp = Total data sent in MegaByte
			//double tmp = datasz / 1e6 * 1000;
			 double tmp = (datasz * 2) / MG * iteration;
			//printf("datasz =%d tmp = %lf\n", datasz,tmp);
			//printf("** %d total data sent in MB = %f time took %f\n", datasz,tmp,t);fflush(stdout);
			fprintf(stdout, "%-*d%*.*f\n", 10, datasz, FIELD_WIDTH,	FLOAT_PRECISION, tmp / t);

			fflush(stdout);
        }
		}	
	}
	#endif
  free(sendbuf);
  free(recvbuf);

  MPI_Finalize();
}
