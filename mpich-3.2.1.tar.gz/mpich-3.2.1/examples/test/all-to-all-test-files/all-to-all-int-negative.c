#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>
#include <assert.h>

int local_int[10000];
  int local_array[10000];

int main(int argc, char** argv) {


  MPI_Init(NULL, NULL);

  int world_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  int world_size;
  
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);

  

  //printf("Try encrypted part with boring............\n");fflush(stdout);
  // init_crypto();
 // init_boringssl_256_siv();
  
    

  if(world_rank == 0){
      for(int i=0;i<2500;i++)
         local_int[i]=-9;
      for(int i=2500;i<5000;i++)
         local_int[i]=-8;
      for(int i=5000;i<7500;i++)
         local_int[i]=-7;
      for(int i=7500;i<10000;i++)
         local_int[i]=-6;         
  }

  if(world_rank == 1){
      for(int i=0;i<2500;i++)
         local_int[i]=-10;
      for(int i=2500;i<5000;i++)
         local_int[i]=-11;
      for(int i=5000;i<7500;i++)
         local_int[i]=-12;
      for(int i=7500;i<10000;i++)
         local_int[i]=-13;  
  }

  if(world_rank == 2){
      for(int i=0;i<2500;i++)
         local_int[i]=-21;
      for(int i=4;i<5000;i++)
         local_int[i]=-22;
      for(int i=8;i<7500;i++)
         local_int[i]=23;
      for(int i=12;i<10000;i++)
         local_int[i]=-24;  
  }
  if(world_rank == 3){
      for(int i=0;i<2500;i++)
         local_int[i]=-34;
      for(int i=4;i<5000;i++)
         local_int[i]=-35;
      for(int i=8;i<7500;i++)
         local_int[i]=-36;
      for(int i=12;i<10000;i++)
         local_int[i]=-37;  
  //local_int[9]='\0';
  }
  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Alltoall(local_int, 10, MPI_INT, local_array, 10, MPI_INT, MPI_COMM_WORLD);
  //printf("Rank %d received %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
  //world_rank, local_array[0], local_array[1], local_array[2], local_array[3], local_array[4], local_array[5], local_array[6], local_array[7],
  //local_array[8], local_array[9], local_array[10], local_array[11], local_array[12], local_array[13], local_array[14], local_array[15]); fflush(stdout);
  if(world_rank == 0){
     printf("rank =%d data received:\n",world_rank);
     for(int i=0;i<world_size*10;i++)
      printf("%d, ",local_array[i]);fflush(stdout);
     printf("\n\n");
  }

  MPI_Barrier(MPI_COMM_WORLD);
  if(world_rank == 1){
     printf("rank =%d data received:\n",world_rank);
     for(int i=0;i<world_size*10;i++)
      printf("%d, ", local_array[i]);fflush(stdout);
     printf("\n\n");
  }
  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Finalize();
}
