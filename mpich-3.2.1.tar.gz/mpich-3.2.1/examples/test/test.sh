#!/bin/sh
set -e
set -x
export LD_LIBRARY_PATH=/home/mpiuser/sc-2019/mpich-3.2.1/install/lib:/home/mpiuser/boringssl/build/crypto
mpicc=/home/mpiuser/sc-2019/mpich-3.2.1/install/bin/mpicc
mpiexec=/home/mpiuser/sc-2019/mpich-3.2.1/install/bin/mpiexec

# ------------------------------
# send & receive test
$mpicc -o send-recv send-recv.c
$mpiexec -n 2  ./send-recv