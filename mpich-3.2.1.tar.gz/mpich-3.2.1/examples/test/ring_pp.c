#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define FLOAT_PRECISION 5
#define FIELD_WIDTH 20
#define sz 4*1024*1024
#define MG 1048576.00
#define low 1*1024//4*1024//512*1024 
#define high 4*1024*1024//(4*1024*1024)*1.1
#define times 1000
#define max_pack 2*1024
#define SIZE_NUM 10 //10 //11
#define key_size 16
#define normal 1



static int lengths[SIZE_NUM+10] = { 1 , 16 , 256 , 1024, 4*1024 , 16*1024 , 64*1024 , 256*1024 , 1024*1024 , 2*1024*1024 , 4* 1024*1024};





int main(int argc, char** argv) {



  MPI_Init(NULL, NULL);
  MPI_Request request;
  MPI_Status status;
  int world_rank,world_size,j,datasz,iteration,datasz1, sendrank, recvrank;
  char * sendbuf, *recvbuf;
  double t_start, t_end, t;
  //struct timeval  tv1, tv2;

  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);

  sendbuf = (char *)malloc(sz * sizeof(char));
  recvbuf = (char *)malloc(sz * sizeof(char));

  memset(sendbuf,'a',4194304);
  memset(recvbuf,'b',4194304);




  
	if(world_rank == 0) printf("\n# Size           Bandwidth (MB/s)\n");
	
	iteration = times;
	int indx;
	
	if (normal){
	   for(indx=0; indx<SIZE_NUM; indx++){    
			datasz=lengths[indx];
			if(datasz > 1024*1024)       iteration = 1000;

		   for(j=1;j<=iteration+20;j++){
					if(j == 20){
					  t_start = MPI_Wtime();
					}
					if (world_rank == 0) {
						  
						  MPI_Send(sendbuf, datasz, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
						  //printf("rank =%d sent to 1\n", world_rank);fflush(stdout);
						  MPI_Recv(recvbuf, datasz, MPI_CHAR, world_size-1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
						  //printf("rank =%d recv from %d\n", world_rank, world_size-1);fflush(stdout);

					}
					else{
                          sendrank = (world_rank +1 )%world_size;
						  MPI_Recv(recvbuf, datasz, MPI_CHAR, world_rank-1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                         // printf("rank =%d recv from %d\n", world_rank, world_rank-1);fflush(stdout);
						  MPI_Send(sendbuf, datasz, MPI_CHAR, sendrank, 0, MPI_COMM_WORLD);
                       //   printf("rank =%d sent to %d\n", world_rank, sendrank);fflush(stdout);
					}
                    //if(world_rank == 0)
                     //printf("%d iteration done\n----------------\n",j);
				}
			t_end = MPI_Wtime();
			if(world_rank == 0) {
				t = t_end - t_start;
				 double tmp = (datasz * 2) / MG * iteration;

			   fprintf(stdout, "%-*d%*.*f\n", 10, datasz, FIELD_WIDTH,
							FLOAT_PRECISION, tmp / t);

				fflush(stdout);
				}
	  }
	//libdumpi_disable_profiling();

	}
	
  free(sendbuf);
  free(recvbuf);

  MPI_Finalize();
}
