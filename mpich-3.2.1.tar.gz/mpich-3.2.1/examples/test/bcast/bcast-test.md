[Rank 0] Encrypted 256 bytes for 1
[Rank 0] Encrypted 256 bytes for 2
[Rank 0] Encrypted 256 bytes for 3
[0]: Before Bcast, 0 0 0 0 0 0 0 0 0 0
[Rank 3] Decrypted size is 16
[3]: Before Bcast, 3 3 3 3 3 3 3 3 3 3
[Rank 1] Decrypted size is 16
[1]: Before Bcast, 1 1 1 1 1 1 1 1 1 1
[Rank 2] Decrypted size is 16
[2]: Before Bcast, 2 2 2 2 2 2 2 2 2 2
MPI_SEC_Bcast: ciphertext_len = 56 Rank = 0
[0]: After Bcast, -11 -11 -11 -11 -11 21 21 21 21 21
MPI_SEC_Bcast: decrypted_len = 40 Rank = 1
[1]: After Bcast, -11 -11 -11 -11 -11 21 21 21 21 21
MPI_SEC_Bcast: decrypted_len = 40 Rank = 2
[2]: After Bcast, -11 -11 -11 -11 -11 21 21 21 21 21
MPI_SEC_Bcast: decrypted_len = 40 Rank = 3
[3]: After Bcast, -11 -11 -11 -11 -11 21 21 21 21 21
[Rank 0] Encrypted 256 bytes for 1
[Rank 0] Encrypted 256 bytes for 2
[Rank 0] Encrypted 256 bytes for 3
[0]: Before Bcast, 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000
[Rank 1] Decrypted size is 16
[1]: Before Bcast, 1.000000 1.000000 1.000000 1.000000 1.000000 1.000000 1.000000 1.000000 1.000000 1.000000
[Rank 3] Decrypted size is 16
[3]: Before Bcast, 3.000000 3.000000 3.000000 3.000000 3.000000 3.000000 3.000000 3.000000 3.000000 3.000000
[Rank 2] Decrypted size is 16
[2]: Before Bcast, 2.000000 2.000000 2.000000 2.000000 2.000000 2.000000 2.000000 2.000000 2.000000 2.000000
MPI_SEC_Bcast: ciphertext_len = 56 Rank = 0
[0]: After Bcast, -51.000000 -51.000000 -51.000000 -51.000000 -51.000000 21.222200 21.222200 21.222200 21.222200 21.222200
MPI_SEC_Bcast: decrypted_len = 40 Rank = 1
MPI_SEC_Bcast: decrypted_len = 40 Rank = 2
[2]: After Bcast, -51.000000 -51.000000 -51.000000 -51.000000 -51.000000 21.222200 21.222200 21.222200 21.222200 21.222200
[1]: After Bcast, -51.000000 -51.000000 -51.000000 -51.000000 -51.000000 21.222200 21.222200 21.222200 21.222200 21.222200
MPI_SEC_Bcast: decrypted_len = 40 Rank = 3
[3]: After Bcast, -51.000000 -51.000000 -51.000000 -51.000000 -51.000000 21.222200 21.222200 21.222200 21.222200 21.222200
