[Rank 0] Encrypted 256 bytes for 1
[Rank 0] Encrypted 256 bytes for 2
[Rank 0] Encrypted 256 bytes for 3
Try encrypted part............MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 0
[Rank 1] Decrypted size is 16
Try encrypted part............[Rank 3] Decrypted size is 16
Try encrypted part............MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 1
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 3
[Rank 2] Decrypted size is 16
Try encrypted part............MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
Rank 0 received 9 9 9 9 8 8 8 8 5 5 5 5 2 2 2 2
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
Rank 1 received 9 9 9 9 8 8 8 8 5 5 5 5 2 2 2 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
Rank 2 received 9 9 9 9 8 8 8 8 5 5 5 5 2 2 2 2
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
Rank 3 received 9 9 9 9 8 8 8 8 5 5 5 5 2 2 2 2
[Rank 0] Encrypted 256 bytes for 1
[Rank 0] Encrypted 256 bytes for 2
[Rank 0] Encrypted 256 bytes for 3
Try encrypted part............
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 0
[Rank 1] Decrypted size is 16
[Rank 2] Decrypted size is 16
Try encrypted part............
[Rank 3] Decrypted size is 16
Try encrypted part............
Try encrypted part............
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 1
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 2
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
Rank 0 received -9 -9 -9 -9 8 8 8 8 -5 -5 -5 -5 -2 -2 -2 -2
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
Rank 1 received -9 -9 -9 -9 8 8 8 8 -5 -5 -5 -5 -2 -2 -2 -2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
Rank 2 received -9 -9 -9 -9 8 8 8 8 -5 -5 -5 -5 -2 -2 -2 -2
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
Rank 3 received -9 -9 -9 -9 8 8 8 8 -5 -5 -5 -5 -2 -2 -2 -2
[Rank 0] Encrypted 256 bytes for 1
[Rank 0] Encrypted 256 bytes for 2
[Rank 0] Encrypted 256 bytes for 3
Try encrypted part............
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 0
[Rank 1] Decrypted size is 16
Try encrypted part............
[Rank 2] Decrypted size is 16
Try encrypted part............
[Rank 3] Decrypted size is 16
Try encrypted part............
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 1
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 2
MPI_SEC_Allgather: ciphertext_sendbuf_len = 32 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 0
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
MPI_SEC_Allgather: decypted = 16 Rank = 1
Rank 1 received -9.500000 -9.500000 -9.500000 -9.500000 8.300000 8.300000 8.300000 8.300000 -5.000000 -5.000000 -5.000000 -5.000000 -2.999000 -2.999000 -2.999000 -2.999000
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
MPI_SEC_Allgather: decypted = 16 Rank = 2
Rank 2 received -9.500000 -9.500000 -9.500000 -9.500000 8.300000 8.300000 8.300000 8.300000 -5.000000 -5.000000 -5.000000 -5.000000 -2.999000 -2.999000 -2.999000 -2.999000
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
MPI_SEC_Allgather: decypted = 16 Rank = 3
Rank 3 received -9.500000 -9.500000 -9.500000 -9.500000 8.300000 8.300000 8.300000 8.300000 -5.000000 -5.000000 -5.000000 -5.000000 -2.999000 -2.999000 -2.999000 -2.999000
Rank 0 received -9.500000 -9.500000 -9.500000 -9.500000 8.300000 8.300000 8.300000 8.300000 -5.000000 -5.000000 -5.000000 -5.000000 -2.999000 -2.999000 -2.999000 -2.999000
